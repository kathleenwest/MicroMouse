void main(){
    int array1[] = {0, 1, 2, 3, 4, 5};
    char array2[] = {"hi", "ho", "fom"};
    char string1[] = "Hello World";
    retrieve_element(1,array1);
}

float hypotenuse(int a, int b) {
    float h;
    h = sqrt((float)(square(a) + square(b)));
    return h;
}

int square(int n) {
    return n*n;   
}

int retrieve_element(int index, int array[]){
    return array[index];   
}